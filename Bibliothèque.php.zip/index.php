

<!DOCTYPE html>

<html lang="FR"> 
<head>
  <meta charset="utf-8"/>
    
    <link rel="stylesheet" href="style.css" />
    </head>

    

    <body style="background-color: GREY;">

<header>

<div class="BOOK">
      <h1>Welcome To MehdiBook's Stor</h1>

      <form action="connect.php" method="GET">

      <p><input type="text" name="Nom" placeholder="Votre Nom"  style="width: 200px; height: 30PX; border: 3PX GREY SOLID;  "></p>

      <p><input type="text" name="Prenom" placeholder="Votre Prenom"  style="width : 200PX; height: 30PX; border: 3PX GREY solid;" ></p>

      <h4 style="text-decoration: underline; ">Si vous etes pas encore membre,merci de renseigner les éléments si-dessous!!</h4>

      <p><input type="text" name="email" placeholder="Votre Adresse Mail" style="width: 200PX;height: 30PX; border: 3PX  GREY SOLID; " ></p>

      <input type="password" name="password" placeholder="Votre Mot De Passe"  style="width: 200PX;height: 30PX; border: 3PX  GREY SOLID; " >


      <p><input type="checkbox" name="box">
      <label for="box"> Se Souvenir De Moi</label></p>

      <input type="submit" name="Se Connecter" value="Se Connecter" style="font-family: impact;">

      </form>

</header> 
</div>


 <h1 style="text-align: center;">Qui somme-nous?</h1>

 <footer style="display: flex;  ">
<p style="font-family: impact; text-shadow: 5PX 5PX 5PX GREY; " >Mehdibook's stor is one of the book's providers in Morocco and North Africa,out customers trust us because we give them a verry good experience while buying from us  </p> 

<ul style="color: RED; font-family: arial;font-weight: bold; ">
  <li>Téléphone:0669419813</li>
  <li>Adresse:Hay Hassani Derb Houria Casablanca</li>
  <li>Email: contact@gmail.com</li>
</ul>

<ul style="color: RED; font-family: arial;font-weight: bold; ">
  <li>Facebook: Mehdi Biblat</li>
  <li>Instagram:#Mehdibook's stor</li>
  <li>Twitter:Mehdi Twitte</li>

</ul>








    </body>







?>